<?php
header("Location: vista/login.php");
exit();
?>
